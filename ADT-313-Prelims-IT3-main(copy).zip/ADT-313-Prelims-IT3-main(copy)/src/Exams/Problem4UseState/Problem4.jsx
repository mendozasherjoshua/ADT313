// export default function Problem4() {
//   return (
//     <>
//       <div style={{ display: 'block' }}>
//         Name: <input type='text' />
//       </div>
//       <div style={{ display: 'block' }}>
//         <p>Yearlevel:</p>
//         <input type='radio' id='firstYear' name='yearlevel' value='Fist Year' />
//           <label for='firstYear'>Fist Year</label>
//         <br></br>
//         <input
//           type='radio'
//           id='secondYear'
//           name='yearlevel'
//           value='Second Year'
//         />
//           <label for='secondYear'>Second Year</label>
//         <br></br>
//         <input
//           type='radio'
//           id='thirdYear'
//           name='yearlevel'
//           value='Third Year'
//         />
//           <label for='thirdYear'>Third Year</label>
//         <br></br>
//         <input
//           type='radio'
//           id='fourthYear'
//           name='yearlevel'
//           value='Fourth Year'
//         />
//           <label for='fourthYear'>Fourth Year</label>
//         <br></br>
//         <input
//           type='radio'
//           id='fifthYear'
//           name='yearlevel'
//           value='Fourth Year'
//         />
//           <label for='fifthYear'>Fifth Year</label>
//         <br></br>
//         <input type='radio' id='irregular' name='yearlevel' value='Irregular' />
//           <label for='irregular'>Irregular</label>
//         <br></br>
//       </div>
//       <div style={{ display: 'block' }}>
//         Course:
//         <select>
//           <option value='BSCS'>BSCS</option>
//           <option value='BSIT'>BSIT</option>
//           <option value='BSCpE'>BSCpE</option>
//           <option value='ACT'>ACT</option>
//         </select>
//       </div>
//     </>
//   );
// }

import React, { useState } from 'react';

export default function Problem4() {
  const [name, setName] = useState('');
  const [yearLevel, setYearLevel] = useState('');
  const [course, setCourse] = useState('BSCS');

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Name: ${name}\nYear Level: ${yearLevel}\nCourse: ${course}`);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div style={{ display: 'block' }}>
        Name: <input type='text' value={name} onChange={(e) => setName(e.target.value)} />
      </div>
      <div style={{ display: 'block' }}>
        <p>Year Level:</p>
        <input type='radio' id='firstYear' name='yearlevel' value='First Year' checked={yearLevel === 'First Year'} onChange={(e) => setYearLevel(e.target.value)} />
        <label htmlFor='firstYear'>First Year</label>
        <br />
        <input type='radio' id='secondYear' name='yearlevel' value='Second Year' checked={yearLevel === 'Second Year'} onChange={(e) => setYearLevel(e.target.value)} />
        <label htmlFor='secondYear'>Second Year</label>
        <br />
        <input type='radio' id='thirdYear' name='yearlevel' value='Third Year' checked={yearLevel === 'Third Year'} onChange={(e) => setYearLevel(e.target.value)} />
        <label htmlFor='thirdYear'>Third Year</label>
        <br />
        <input type='radio' id='fourthYear' name='yearlevel' value='Fourth Year' checked={yearLevel === 'Fourth Year'} onChange={(e) => setYearLevel(e.target.value)} />
        <label htmlFor='fourthYear'>Fourth Year</label>
        <br />
        <input type='radio' id='fifthYear' name='yearlevel' value='Fifth Year' checked={yearLevel === 'Fifth Year'} onChange={(e) => setYearLevel(e.target.value)} />
        <label htmlFor='fifthYear'>Fifth Year</label>
        <br />
        <input type='radio' id='irregular' name='yearlevel' value='Irregular' checked={yearLevel === 'Irregular'} onChange={(e) => setYearLevel(e.target.value)} />
        <label htmlFor='irregular'>Irregular</label>
        <br />
      </div>
      <div style={{ display: 'block' }}>
        Course:
        <select value={course} onChange={(e) => setCourse(e.target.value)}>
          <option value='BSCS'>BSCS</option>
          <option value='BSIT'>BSIT</option>
          <option value='BSCpE'>BSCpE</option>
          <option value='ACT'>ACT</option>
        </select>
      </div>
      <button type='submit'>Submit</button>
    </form>
  );
}