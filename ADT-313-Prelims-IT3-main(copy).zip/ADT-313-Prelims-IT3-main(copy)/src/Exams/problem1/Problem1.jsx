
import React from 'react';

const Problem1 = ({ name }) => {
  return (
    <div>
      <h2>Sher Joshu Mendoza {name}</h2>
      <h3>BSIT 3C {name}</h3>
    </div>
  );

   
  };
export default Problem1;