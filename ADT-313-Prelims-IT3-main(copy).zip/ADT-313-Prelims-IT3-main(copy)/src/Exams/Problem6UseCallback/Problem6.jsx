// import { useCallback, useEffect, useState } from 'react';
// import data from './MOCK_DATA.json';
// export default function Problem6() {
//   const [cars, setCars] = useState(data);
//   const [selected, setSelected] = useState();

//   return (
//     <>
//       <div>
//         <div style={{ display: 'block' }}>
//           VIN:{' '}
//           <input
//             type='text'
//             value={selected && selected.vin ? selected.vin : ''}
//           />
//         </div>
//         <div style={{ display: 'block' }}>
//           Make:{' '}
//           <input
//             type='text'
//             value={selected && selected.make ? selected.make : ''}
//           />
//         </div>
//         <div style={{ display: 'block' }}>
//           Model:{' '}
//           <input
//             type='text'
//             value={selected && selected.model ? selected.model : ''}
//           />
//         </div>
//         <div style={{ display: 'block' }}>
//           Year:{' '}
//           <input
//             type='text'
//             value={selected && selected.year ? selected.year : ''}
//           />
//         </div>
//         <div style={{ display: 'block' }}>
//           Color:{' '}
//           <input
//             type='text'
//             value={selected && selected.color ? selected.color : ''}
//           />
//         </div>
//         <button type='button'>Save</button>
//         <button type='button'>Clear</button>
//       </div>
//       <div className='table-container'>
//         <table style={{ width: '100%' }}>
//           <thead>
//             <tr>
//               <th>VIN</th>
//               <th>Make</th>
//               <th>Model</th>
//               <th>Year</th>
//               <th>Color</th>
//               <th>Actions</th>
//             </tr>
//           </thead>
//           <tbody style={{ textAlign: 'center' }}>
//             {cars.map((car, index) => {
//               return (
//                 <tr>
//                   <td>{car.vin}</td>
//                   <td>{car.make}</td>
//                   <td>{car.model}</td>
//                   <td>{car.year}</td>
//                   <td>{car.color}</td>
//                   <td>
//                     <button type='button'>Edit</button>
//                     <button type='button'>Delete</button>
//                   </td>
//                 </tr>
//               );
//             })}
//           </tbody>
//         </table>
//       </div>
//     </>
//   );
// }
import { useCallback, useState } from 'react';
import data from './MOCK_DATA.json';

export default function Problem6() {
  const [cars, setCars] = useState(data);
  const [selected, setSelected] = useState(null);
  const [vin, setVin] = useState('');
  const [make, setMake] = useState('');
  const [model, setModel] = useState('');
  const [year, setYear] = useState('');
  const [color, setColor] = useState('');

  // Edit function to populate form with the selected car's details
  const handleEdit = useCallback((car) => {
    setSelected(car);
    setVin(car.vin);
    setMake(car.make);
    setModel(car.model);
    setYear(car.year);
    setColor(car.color);
  }, []);

  // Delete function to remove a car
  const handleDelete = useCallback((vinToDelete) => {
    setCars((prevCars) => prevCars.filter((car) => car.vin !== vinToDelete));
  }, []);

  // Save function to add a new car
  const handleSave = useCallback(() => {
    const newCar = { vin, make, model, year, color };
    setCars((prevCars) => [...prevCars, newCar]);
    clearForm();
  }, [vin, make, model, year, color]);

  // Update function to update the selected car
  const handleUpdate = useCallback(() => {
    const updatedCars = cars.map((car) =>
      car.vin === selected.vin
        ? { vin, make, model, year, color }
        : car
    );
    setCars(updatedCars);
    clearForm();
  }, [cars, vin, make, model, year, color, selected]);

  // Clear form function
  const clearForm = useCallback(() => {
    setVin('');
    setMake('');
    setModel('');
    setYear('');
    setColor('');
    setSelected(null);
  }, []);

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          VIN:{' '}
          <input
            type='text'
            value={vin}
            onChange={(e) => setVin(e.target.value)}
          />
        </div>
        <div style={{ display: 'block' }}>
          Make:{' '}
          <input
            type='text'
            value={make}
            onChange={(e) => setMake(e.target.value)}
          />
        </div>
        <div style={{ display: 'block' }}>
          Model:{' '}
          <input
            type='text'
            value={model}
            onChange={(e) => setModel(e.target.value)}
          />
        </div>
        <div style={{ display: 'block' }}>
          Year:{' '}
          <input
            type='text'
            value={year}
            onChange={(e) => setYear(e.target.value)}
          />
        </div>
        <div style={{ display: 'block' }}>
          Color:{' '}
          <input
            type='text'
            value={color}
            onChange={(e) => setColor(e.target.value)}
          />
        </div>
        <button type='button' onClick={handleSave}>
          Save
        </button>
        <button type='button' onClick={clearForm}>
          Clear
        </button>
      </div>
      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>VIN</th>
              <th>Make</th>
              <th>Model</th>
              <th>Year</th>
              <th>Color</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {cars.map((car) => {
              return (
                <tr key={car.vin}>
                  <td>{car.vin}</td>
                  <td>{car.make}</td>
                  <td>{car.model}</td>
                  <td>{car.year}</td>
                  <td>{car.color}</td>
                  <td>
                    <button type='button' onClick={() => handleEdit(car)}>
                      Edit
                    </button>
                    <button
                      type='button'
                      onClick={() => handleDelete(car.vin)}
                    >
                      Delete
                    </button>
                    {selected && selected.vin === car.vin && (
                      <button type='button' onClick={handleUpdate}>
                        Update
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}