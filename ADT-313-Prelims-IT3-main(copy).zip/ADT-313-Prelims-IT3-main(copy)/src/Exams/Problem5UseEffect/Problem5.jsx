// import { useEffect, useRef, useState } from 'react';
// import Loading from './Problem5Components/Loading';
// export default function Problem5() {
//   const [isLoading, setIsLoading] = useState(true);

//   return (
//     <>
//       {isLoading ? (
//         <Loading />
//       ) : (
//         <>
//           <div style={{ display: 'block' }}>
//             Input: <input type='text' />
//             <p>User is idle...</p>
//           </div>
//         </>
//       )}
//     </>
//   );
// }



import { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [isIdle, setIsIdle] = useState(true);
  const timerRef = useRef(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false); 
    }, 3000);

    return () => clearTimeout(timer); 
  }, []);

  const handleUserInput = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }

    setIsIdle(false); 

    timerRef.current = setTimeout(() => {
      setIsIdle(true); 
    }, 500); 
  };

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <div style={{ display: 'block' }}>
          Input: <input type='text' onChange={handleUserInput} placeholder="Type something..." />
          <p>{isIdle ? "User is idle..." : "User is typing..."}</p>
        </div>
      )}
    </>
  );
}