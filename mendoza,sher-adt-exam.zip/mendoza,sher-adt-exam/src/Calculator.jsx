import React, { useState } from 'react';

function Calculator() {
  const [input1, setInput1] = useState('');
  const [input2, setInput2] = useState('');
  const [operation, setOperation] = useState('+');
  const [result, setResult] = useState('');

  const calculate = () => {
    const num1 = parseFloat(input1);
    const num2 = parseFloat(input2);

    switch (operation) {
      case '+':
        setResult(num1 + num2);
        break;
      case '-':
        setResult(num1 - num2);
        break;
      case '*':
        setResult(num1 * num2);
        break;
      case '/':
        setResult(num1 / num2);
        break;
      default:
        setResult('');
    }
  };

  return (
    <div className="calculator">
      <h3>Calculator</h3>
      <div className="calc-container">
        <input
          type="number"
          value={input1}
          onChange={(e) => setInput1(e.target.value)}
          placeholder="Input 1"
        />
        <span className="operation-symbol">{operation}</span>
        <input
          type="number"
          value={input2}
          onChange={(e) => setInput2(e.target.value)}
          placeholder="Input 2"
        />
        <span className="equals-symbol">=</span>
        <div className="result-box">{result}</div>
        <button onClick={calculate} className="calculate-button">Calculate</button>
      </div>
      <div className="operation-buttons">
        <button onClick={() => setOperation('+')}>Addition</button>
        <button onClick={() => setOperation('-')}>Subtraction</button>
        <button onClick={() => setOperation('*')}>Multiplication</button>
        <button onClick={() => setOperation('/')}>Division</button>
      </div>
    </div>
  );
}

export default Calculator;