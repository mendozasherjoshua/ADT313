// import React from 'react';

// function UserInfo() {
//   return (
//     <div>
//       <h3>User Information</h3>
//       <p>Name: Mendoza, Sher Joshua</p>
//       <p>Section/Year: BSIT-3C</p>
//     </div>
//   );
// }

// export default UserInfo;




import React from 'react';

function UserInfo({ onLogout }) {
  return (
    <div className="user-info">
      {/* <h3>User Information</h3> */}
      <p>Firstname: Sher Joshua</p>
      <p>Middlename: Francisco</p>
      <p>Lastname: Mendoza</p>
      <p>Section: BSIT-3C</p>
      <button onClick={onLogout} className="logout-button">Logout</button>
    </div>
  );
}

export default UserInfo;