// 

// import React, { useState } from 'react';
// import Login from './Login.jsx';
// import UserInfo from './UserInfo.jsx';
// import Calculator from './Calculator.jsx';
// import './styles.css';


// function App() {
//   const [isLoggedIn, setIsLoggedIn] = useState(false);
//   const [isLoading, setIsLoading] = useState(false);

//   const handleLogin = async (username, password) => {
//     if (username === 'User' && password === 'Password123@') {
//       setIsLoading(true);
//       await new Promise(resolve => setTimeout(resolve, 2000)); // 2 second delay
//       setIsLoggedIn(true);
//       setIsLoading(false);
//     } else {
//       alert('Invalid username or password');
//     }
//   };

//   const handleLogout = () => {
//     setIsLoggedIn(false);
//   };

//   return (
//     <div className="App">
//       <h1>Sher Joshua Mendoza</h1>
//       <h2>BSIT - 3C</h2>
//       {isLoading ? (
//         <p>Loading...</p>
//       ) : isLoggedIn ? (
//         <UserInfo onLogout={handleLogout} />
//       ) : (
//         <Login onLogin={handleLogin} />
//       )}
//       <Calculator />
//     </div>
//   );
  
   
// }


// export default App;



// App.js
import React, { useState } from 'react';
import Login from './Login.jsx';
import UserInfo from './UserInfo.jsx';
import Calculator from './Calculator.jsx';
import './styles.css';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (username, password) => {
    if (username === 'User' && password === 'Password123@') {
      setIsLoading(true);
      await new Promise(resolve => setTimeout(resolve, 2000)); // 2 second delay
      setIsLoggedIn(true);
      setIsLoading(false);
    } else {
      alert('Invalid username or password');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  return (
    <div className="App">
      <div className="header">
        <h2 className="name">sher joshua mendoza</h2>
        <h2 className="section">bsit - 3c</h2>
        <br />
        
      </div>
      {isLoading ? (
        <p>Loading...</p>
      ) : isLoggedIn ? (
        <UserInfo onLogout={handleLogout} />
      ) : (
        <Login onLogin={handleLogin} />
      )}
      <Calculator />
    </div>
  );
}

export default App;